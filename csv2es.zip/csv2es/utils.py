def log(*args, **kvarg):
    print(*args, **kvarg, flush=True)