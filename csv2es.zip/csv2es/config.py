def get_config():
    return {
        'es': {
            'host': 'http://10.8.60.127:9200',
            'user': None,
            'password': None,
        }
    }