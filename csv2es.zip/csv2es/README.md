# 执行语句

```
// file_path中的文件名会被当做索引名称
pipenv run python main.py --file_path=./zsy_material_information.csv
```
